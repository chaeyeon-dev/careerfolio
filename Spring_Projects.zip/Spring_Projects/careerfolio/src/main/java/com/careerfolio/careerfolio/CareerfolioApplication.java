package com.careerfolio.careerfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareerfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareerfolioApplication.class, args);
	}

}
